# Project #3 – Multithreading
* Lab machine name used to test your program
* Project group number, group member names and x500 addresses
* Whether to complete the extra task
* Members’ individual contributions
* Any assumptions outside this document
* How to compile and run your program
