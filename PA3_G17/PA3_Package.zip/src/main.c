#include "header.h"

/**
 * Write final balance to a single file.
 * The path name should be output/result.txt
 */
void writeBalanceToFiles(void) {
    // TODO: write balance for each customer 
    
    // TODO: write total balance change
}

int main(int argc, char *argv[]){
    
    //TODO: Argument check

    bookeepingCode();
    
    //TODO: Initialize global variables, like shared queue
    
    //TODO: create producer and consumer threads

    //TODO: wait for all threads to complete execution
    
    //Write the final output
    writeBalanceToFiles();
    
    return 0; 
}