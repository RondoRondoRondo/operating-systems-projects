#include "consumer.h"
#include <ctype.h>

/**
 * parse lines from the queue, calculate balance change
 * and update to global array
 */
void parse(char *line){
    
    // TODO: get customer id

    // TODO: sum up transactions

    // TODO: update the global array


}


// consumer function
void *consumer(void *arg){
    
    //TODO: keep reading from queue and process the data
    // feel free to change
    while(1){
        //parse();
    }
    
    return NULL; 
}


