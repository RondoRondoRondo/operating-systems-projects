#ifndef HEADER_H
#define HEADER_H

#include "utils.h"
#include "producer.h"
#include "consumer.h"

char *finalDir = "output/result.txt";
char *logDir = "output/log.txt";

#endif