#ifndef PRODUCER_H
#define PRODUCER_H

#include "utils.h"

void *producer(void *arg);

#endif